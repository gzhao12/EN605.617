//Based on the work of Andrew Krepps
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

__device__ void copy_data_to_shared(const int * const data,
                                    int * const tmp,
                                    const int num_elements,
                                    const int tid) {
    for (int i = 0; i < num_elements; i++) {
        tmp[i + tid] = data[i + tid];
    }
    __syncthreads();
}

__device__ void copy_data_to_global(int * const tmp,
                                    const int * const data,
                                    const int num_elements,
                                    const int tid) {
    for (int i = 0; i < num_elements; i++) {
        data[i + tid] = tmp[i + tid];
    }
    __syncthreads();
}

__device__ void add_shared(int * a, int * b, int * c) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
	c[i] = a[i] + b[i];
}

__device__ void subtract_shared(int * a, int * b, int * c) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
	c[i] = b[i] - a[i];
}

__device__ void mult_shared(int * a, int * b, int * c) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
	c[i] = a[i] * b[i];
}

__device__ void mod_shared(int * a, int * b, int * c) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
	c[i] = a[i] % b[i];
}

__device__ void caesar_cipher(char * a, char * b, int length, int offset) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
	if (i < length) {
		char tmp = a[i];
		if (offset > 0) {
			if (tmp >= 'a' && tmp <= 'z') {
				tmp = tmp + offset;
				if (tmp > 'z') {
					tmp = tmp - 'z' + 'a' - 1;
				}
			}
			else if (tmp >= 'A' && tmp <= 'Z') {
				tmp = tmp + offset;
				if (tmp > 'Z') {
					tmp = tmp - 'Z' + 'A' - 1;
				}
			}
			b[i] = tmp;
		}
		else {
			if (tmp >= 'a' && tmp <= 'z') {
				tmp = tmp + offset;
				if (tmp < 'A') {
					tmp = tmp + 'z' - 'a' + 1;
				}
			}
			else if (tmp >= 'A' && tmp <= 'Z') {
				tmp = tmp + offset;
				if (tmp < 'A') {
					tmp = tmp + 'Z' - 'A' + 1;
				}
			}
			b[i] = tmp;
		}
	}
}

__global__ void dev_add_shared(const int * const a, const int * const b, 
                               const int * const c, const int num_elements) {
    const int tid = (blockIdx.x * blockDim.x) + threadIdx.x;
    __shared__ int a_tmp[num_elements];
    __shared__ int b_tmp[num_elements];
    __shared__ int c_tmp[num_elements];
    copy_data_to_shared(a, a_tmp, num_elements, tid);
    copy_data_to_shared(b, b_tmp, num_elements, tid);
    copy_data_to_shared(c, c_tmp, num_elements, tid);

    add_shared(a_tmp, b_tmp, c_tmp)

    copy_data_to_global(c_tmp, c, num_elements, tid);
}

__global__ void dev_subtract_shared(const int * const a, const int * const b, 
                                    const int * const c, const int num_elements) {
    const int tid = (blockIdx.x * blockDim.x) + threadIdx.x;
    __shared__ int a_tmp[num_elements];
    __shared__ int b_tmp[num_elements];
    __shared__ int c_tmp[num_elements];
    copy_data_to_shared(a, a_tmp, num_elements, tid);
    copy_data_to_shared(b, b_tmp, num_elements, tid);
    copy_data_to_shared(c, c_tmp, num_elements, tid);

    subtract_shared(b_tmp, a_tmp, c_tmp)

    copy_data_to_global(c_tmp, c, num_elements, tid);
}

__global__ void dev_mult_shared(const int * const a, const int * const b, 
                                const int * const c, const int num_elements) {
    const int tid = (blockIdx.x * blockDim.x) + threadIdx.x;
    __shared__ int a_tmp[num_elements];
    __shared__ int b_tmp[num_elements];
    __shared__ int c_tmp[num_elements];
    copy_data_to_shared(a, a_tmp, num_elements, tid);
    copy_data_to_shared(b, b_tmp, num_elements, tid);
    copy_data_to_shared(c, c_tmp, num_elements, tid);

    mult_shared(a_tmp, b_tmp, c_tmp)

    copy_data_to_global(c_tmp, c, num_elements, tid);
}

__global__ void dev_mod_shared(const int * const a, const int * const b, 
                               const int * const c, const int num_elements) {
    const int tid = (blockIdx.x * blockDim.x) + threadIdx.x;
    __shared__ int a_tmp[num_elements];
    __shared__ int b_tmp[num_elements];
    __shared__ int c_tmp[num_elements];
    copy_data_to_shared(a, a_tmp, num_elements, tid);
    copy_data_to_shared(b, b_tmp, num_elements, tid);
    copy_data_to_shared(c, c_tmp, num_elements, tid);

    mod_shared(a_tmp, b_tmp, c_tmp)

    copy_data_to_global(c_tmp, c, num_elements, tid);
}

void main_add_shared(int totalThreads, int blockSize, int numBlocks, int *a, 
                     int *b, int *c, int *dev_a, int *dev_b, int *dev_c) {
	dev_add_shared<<<numBlocks, blockSize>>>(dev_a, dev_b, dev_c, totalThreads);
	cudaMemcpy(c, dev_c, totalThreads * sizeof(int), cudaMemcpyDeviceToHost);

	for (int i = 0; i < totalThreads; i++) {
		printf("%d + %d = %d \n", a[i], b[i], c[i]);
	}
}

void main_sub_shared(int totalThreads, int blockSize, int numBlocks, int *a, 
                     int *b, int *c, int *dev_a, int *dev_b, int *dev_c) {
	dev_subtract_shared<<<numBlocks, blockSize>>>(dev_b, dev_a, dev_c, totalThreads);
	cudaMemcpy(c, dev_c, totalThreads * sizeof(int), cudaMemcpyDeviceToHost);

	for (int i = 0; i < totalThreads; i++) {
		printf("%d - %d = %d \n", a[i], b[i], c[i]);
	}
}

void main_mult_shared(int totalThreads, int blockSize, int numBlocks, int *a, 
                      int *b, int *c, int *dev_a, int *dev_b, int *dev_c) {
	dev_mult_shared<<<numBlocks, blockSize>>>(dev_a, dev_b, dev_c, totalThreads);
	cudaMemcpy(c, dev_c, totalThreads * sizeof(int), cudaMemcpyDeviceToHost);

	for (int i = 0; i < totalThreads; i++) {
		printf("%d * %d = %d \n", a[i], b[i], c[i]);
	}
}

void main_mod_shared(int totalThreads, int blockSize, int numBlocks, int *a, 
                     int *b, int *c, int *dev_a, int *dev_b, int *dev_c) {
	dev_mod_shared<<<numBlocks, blockSize>>>(dev_a, dev_b, dev_c, totalThreads);
	cudaMemcpy(c, dev_c, totalThreads * sizeof(int), cudaMemcpyDeviceToHost);
	
	for (int i = 0; i < totalThreads; i++) {
		printf("%d %% %d = %d \n", a[i], b[i], c[i]);
	}
}

void host_caesar_cipher(char *a, char *b, int length, int offset) {
	char *dev_a, *dev_b;
	cudaMalloc(&dev_a, length * sizeof(char));
	cudaMalloc(&dev_b, length * sizeof(char));

	cudaMemcpy(dev_a, a, length * sizeof(char), cudaMemcpyHostToDevice);

	// always one block with length number of threads
	caesar_cipher<<<length, length>>>(dev_a, dev_b, length, offset);
	cudaMemcpy(b, dev_b, length * sizeof(char), cudaMemcpyDeviceToHost);

	cudaFree(dev_a);
	cudaFree(dev_b);
}

void host_shared_main(int totalThreads, int blockSize, int numBlocks) {
	int *a, *b, *c, *dev_a, *dev_b, *dev_c;
	a = (int*)malloc(totalThreads * sizeof(int));
	b = (int*)malloc(totalThreads * sizeof(int));
	c = (int*)malloc(totalThreads * sizeof(int));
	cudaMalloc(&dev_a, totalThreads * sizeof(int));
	cudaMalloc(&dev_b, totalThreads * sizeof(int));
	cudaMalloc(&dev_c, totalThreads * sizeof(int));

	srand(time(NULL));
	for (int i = 0; i < totalThreads; i++) {
		a[i] = i;
		b[i] = rand() % 3;
	}

	cudaMemcpy(dev_a, a, totalThreads * sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(dev_b, b, totalThreads * sizeof(int), cudaMemcpyHostToDevice);

	printf("Calculations for %d block(s) of size %d threads \n", numBlocks, blockSize);
	printf("Addition Calculations: \n");
	main_add_shared(totalThreads, blockSize, numBlocks, a, b, c, dev_a, dev_b, dev_c);
}

int main(int argc, char** argv) {
	// read command line arguments
	int totalThreads = (1 << 20);
	int blockSize = 256;
	
	if (argc >= 2) {
		totalThreads = atoi(argv[1]);
	}
	if (argc >= 3) {
		blockSize = atoi(argv[2]);
	}

	int numBlocks = totalThreads/blockSize;

	// validate command line arguments
	if (totalThreads % blockSize != 0) {
		++numBlocks;
		totalThreads = numBlocks*blockSize;
		
		printf("Warning: Total thread count is not evenly divisible by the block size\n");
		printf("The total number of threads will be rounded up to %d\n", totalThreads);
	}
    
    host_shared_main(totalThreads, blockSize, numBlocks);

	return 0;
}