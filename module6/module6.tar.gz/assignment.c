//Based on the work of Andrew Krepps
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_ELEMENTS 128

__global__ void add(int * a, int * b, int * c, int num_elements) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < num_elements) {
        int a_tmp = a[i];
        int b_tmp = b[i];
        int c_tmp = a_tmp + b_tmp;
        c[i] = c_tmp;
    }
}

__global__ void sub(int * a, int * b, int * c, int num_elements) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < num_elements) {
        int a_tmp = a[i];
        int b_tmp = b[i];
        int c_tmp = a_tmp - b_tmp;
        c[i] = c_tmp;
    }
}

__global__ void mult(int * a, int * b, int * c, int num_elements) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < num_elements) {
        int a_tmp = a[i];
        int b_tmp = b[i];
        int c_tmp = a_tmp * b_tmp;
        c[i] = c_tmp;
    }
}

__global__ void mod(int * a, int * b, int * c, int num_elements) {
	int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < num_elements) {
        int a_tmp = a[i];
        int b_tmp = b[i];
        int c_tmp = a_tmp % b_tmp;
        c[i] = c_tmp;
    }
}

void run_calcs(int *a, int *b, int *c, int *dev_a, int *dev_b, int *dev_c) {
    printf("Calculations for 1 block of size %d threads \n", 
            NUM_ELEMENTS);

	printf("Addition Calculations: \n");
	add<<<1, NUM_ELEMENTS>>>(dev_a, dev_b, dev_c, NUM_ELEMENTS);
    cudaMemcpy(c, dev_c, NUM_ELEMENTS * sizeof(int), cudaMemCpyDeviceToHost);
	for (int i = 0; i < NUM_ELEMENTS; i++) {
		printf("%d + %d = %d \n", a[i], b[i], c[i]);
	}

	printf("Subtraction Calculations: \n");
	sub<<<1, NUM_ELEMENTS>>>(dev_a, dev_b, dev_c, NUM_ELEMENTS);
    cudaMemcpy(c, dev_c, NUM_ELEMENTS * sizeof(int), cudaMemCpyDeviceToHost);
	for (int i = 0; i < NUM_ELEMENTS; i++) {
		printf("%d - %d = %d \n", a[i], b[i], c[i]);
	}

	printf("Multiplication Calculations: \n");
	mult<<<1, NUM_ELEMENTS>>>(dev_a, dev_b, dev_c, NUM_ELEMENTS);
    cudaMemcpy(c, dev_c, NUM_ELEMENTS * sizeof(int), cudaMemCpyDeviceToHost);
	for (int i = 0; i < NUM_ELEMENTS; i++) {
		printf("%d * %d = %d \n", a[i], b[i], c[i]);
	}

	printf("Modulo Calculations: \n");
	mod<<<1, NUM_ELEMENTS>>>(dev_a, dev_b, dev_c, NUM_ELEMENTS);
    cudaMemcpy(c, dev_c, NUM_ELEMENTS * sizeof(int), cudaMemCpyDeviceToHost);
	for (int i = 0; i < NUM_ELEMENTS; i++) {
		printf("%d %% %d = %d \n", a[i], b[i], c[i]);
	}
}

void main_pagable() {
    int *dev_a, *dev_b, *dev_c;
	int a[NUM_ELEMENTS], b[NUM_ELEMENTS], c[NUM_ELEMENTS];
	cudaMalloc(&dev_a, NUM_ELEMENTS * sizeof(int));
	cudaMalloc(&dev_b, NUM_ELEMENTS * sizeof(int));
	cudaMalloc(&dev_c, NUM_ELEMENTS * sizeof(int));

	srand(time(NULL));
	for (int i = 0; i < NUM_ELEMENTS; i++) {
		a[i] = i;
		b[i] = rand() % 3;
	}

	cudaMemcpy(dev_a, a, NUM_ELEMENTS * sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(dev_b, b, NUM_ELEMENTS * sizeof(int), cudaMemcpyHostToDevice);

    run_calcs(a, b, c, dev_a, dev_b, dev_c);

    cudaFree(dev_a);
	cudaFree(dev_b);
	cudaFree(dev_c);
}

int main(int argc, char** argv) {
    main_pageable();

	return 0;
}